//------------------------------------------------------------------
// SSE2033: System Software Experiment 2 (Fall 2019)
//
// Skeleton code for PA #0
//
// Computer Systems and Intelligence Laboratory
// Sungkyunkwan University
//
// Student Name  :
// Student ID No.:
//------------------------------------------------------------------
#include <unistd.h>
#include <fcntl.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main()
{
	return 0;
}

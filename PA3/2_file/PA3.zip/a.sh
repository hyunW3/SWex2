!bin/bash
chmod 777 *
make clean
make
./swsh

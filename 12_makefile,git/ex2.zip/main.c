#include "main.h"

int main(void) {
	hello();
	return 0;
}

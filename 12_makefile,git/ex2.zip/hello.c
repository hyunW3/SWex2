#include <stdio.h>
#include "main.h"

void hello (void) {
	printf("hello");
}

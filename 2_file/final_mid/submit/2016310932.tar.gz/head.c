// 2016310932 Bae HyunWoong
#define MAXARGS   128
#define MAXLINE	  256
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/stat.h>
	int num =10;
void print_file(int argc, int fd, int file_size,int num);
int main(int argc, char** argv) {
	
	struct stat file_info;
	int file_size;
	int fd;
	int check = 0;
	int pos =-1;
	if((argv[1] != NULL) && (!strcmp(argv[1],"-n"))){ // option
		num = atoi(argv[2]);
		if(argv[3] == NULL){
			fd =dup(0);
			file_size = MAXARGS*num;
			print_file(argc,fd,file_size,num);
		} else {			
			stat(argv[3],&file_info);
			file_size = file_info.st_size;
			fd = open(argv[3], O_RDONLY);
			if(fd< 0){
				perror(argv[3]);
			}else {
				print_file(argc,fd,file_size,num);
			}	
		}
	} else if((argv[1] != NULL) && (!strcmp(argv[1],"<"))) { // wrong case
		// do nothing
	}else { // no option
		if(argv[1] == NULL){
			fd =dup(0);
			file_size = MAXARGS*num;	
			print_file(argc,fd,file_size,num);		
		} else {
			fd = open(argv[1], O_RDONLY);
			if(fd <0){
				perror(argv[1]);
			}else {
				stat(argv[1],&file_info);
				file_size = file_info.st_size;
				print_file(argc,fd,file_size,num);
					
			}				
		}
	}
}

void print_file(int argc, int fd, int file_size,int num){
	char** s1 = (char**)malloc(sizeof(char*)*num);
	for(int i=0; i<num; i++){
		s1[i] = (char*)malloc(sizeof(char)*1024);
	}
	int i=0,j=0;
	char buf[2];
	while(read(fd,buf,1) != EOF ){
		s1[i][j++] = buf[0];
		if(buf[0] == '\n'){
			s1[i][j] = '\0';
			j=0;
			write(1,s1[i],strlen(s1[i]));
			if(i>=num) break;
			else {
				 i++;
			}
		}
	}
	for(int i=0; i<num; i++){
		free(s1[i]);
	}	
	free(s1);

}

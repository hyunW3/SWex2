make clean &&
make &&
./server 8888 3 128

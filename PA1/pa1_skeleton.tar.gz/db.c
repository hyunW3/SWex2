/*-----------------------------------------------------------
 *
 * SSE2033: System Software Experiment 2 (Fall 2019)
 *
 * Skeleton code for PA #1
 * 
 * CSI Lab, Sungkyunkwan University
 *
 * Student Id   :
 * Student Name :
 *
 *-----------------------------------------------------------
 */

#include "db.h"
#include <stdio.h>

db_t *db_open(int size)
{
	db_t *db = NULL;
	return db;
}

void db_close(db_t *db)
{

}

void db_put(db_t *db, char *key, int key_len,
			char *val, int val_len)
{

}

/* Returns NULL if not found. A malloc()ed array otherwise.
 * Stores the length of the array in *vallen */
char *db_get(db_t *db, char *key, int key_len,
			int *val_len)
{
	char *value = NULL;
	return value;
}



